// GAMEZONE - PRE-ENTREGA 6
// Funciones de orden superior: forEach(), find(), filter() y some().

// 1) Clase para crear objetos videojuegos.
class Videojuego {
  constructor(id, nombre, precio, categoria, stock) {
    this.id = id;
    this.nombre = nombre;
    this.precio = precio;
    this.categoria = categoria;
    this.stock = stock;
  }

  mostrarInformacion() {
    return `${this.nombre} | $${this.precio} | ${this.categoria} | Stock: ${this.stock}`;
  }
}

// 2) Instancias creadas a partir de la clase del módulo anterior.
const videojuego1 = new Videojuego(1, "Minecraft", 15000, "Aventura", 10);
const videojuego2 = new Videojuego(2, "FIFA 25", 25000, "Deportes", 8);
const videojuego3 = new Videojuego(3, "GTA V", 20000, "Acción", 5);
const videojuego4 = new Videojuego(4, "The Sims 4", 12000, "Simulación", 7);
const videojuego5 = new Videojuego(5, "Fortnite", 18000, "Acción", 12);
const videojuego6 = new Videojuego(6, "Rocket League", 10000, "Deportes", 6);

// Array de objetos: es el catálogo que usa todo el simulador.
const catalogoVideojuegos = [
  videojuego1,
  videojuego2,
  videojuego3,
  videojuego4,
  videojuego5,
  videojuego6
];

// 3) forEach(): recorre todos los videojuegos y muestra sus datos.
function listarVideojuegos() {
  console.log("===== CATÁLOGO COMPLETO (forEach) =====");
  catalogoVideojuegos.forEach((videojuego) => {
    console.log(videojuego.mostrarInformacion());
  });
}

// 4) find(): busca y devuelve el primer videojuego que coincide con el ID.
function buscarPorId(idBuscado) {
  const resultado = catalogoVideojuegos.find((videojuego) => {
    return videojuego.id === idBuscado;
  });

  if (resultado) {
    console.log("Videojuego encontrado:", resultado.mostrarInformacion());
  } else {
    console.log("No se encontró un videojuego con ese ID.");
  }
  return resultado;
}

// 5) filter(): crea un nuevo array con videojuegos cuyo precio sea igual o mayor
// al precio mínimo ingresado. Es el método de transformación de esta entrega.
function filtrarPorPrecio(precioMinimo) {
  const resultado = catalogoVideojuegos.filter((videojuego) => {
    return videojuego.precio >= precioMinimo;
  });

  console.log(`Videojuegos con precio desde $${precioMinimo}:`);
  resultado.forEach((videojuego) => console.log(videojuego.mostrarInformacion()));
  return resultado;
}

// 6) some(): comprueba si existe al menos un videojuego de la categoría indicada.
function existeCategoria(categoriaBuscada) {
  const existe = catalogoVideojuegos.some((videojuego) => {
    return videojuego.categoria.toLowerCase() === categoriaBuscada.toLowerCase();
  });

  console.log(`¿Hay videojuegos de ${categoriaBuscada}?`, existe);
  return existe;
}

// 7) Interacción solicitada por la consigna mediante prompt().
function ejecutarMenu() {
  let continuar = true;

  while (continuar) {
    const opcion = prompt(
      "GAMEZONE - ¿Qué querés hacer?\n\n" +
      "1 - Ver todo el catálogo\n" +
      "2 - Buscar un videojuego por ID\n" +
      "3 - Filtrar videojuegos por precio mínimo\n" +
      "4 - Consultar si existe una categoría\n" +
      "5 - Salir\n\n" +
      "Ingresá el número de la opción:"
    );

    if (opcion === null || opcion === "5") {
      continuar = false;
      alert("Saliste del menú de GameZone.");
    } else if (opcion === "1") {
      listarVideojuegos();
      alert("Se mostró el catálogo completo en la consola (F12).");
    } else if (opcion === "2") {
      const idIngresado = prompt("Ingresá el ID del videojuego (del 1 al 6):");
      if (idIngresado !== null && idIngresado.trim() !== "") {
        const id = Number(idIngresado);
        if (Number.isInteger(id)) {
          const encontrado = buscarPorId(id);
          alert(encontrado ? `Encontrado: ${encontrado.nombre}` : "No existe un videojuego con ese ID.");
        } else {
          alert("Ingresá un número de ID válido.");
        }
      }
    } else if (opcion === "3") {
      const precioIngresado = prompt("Ingresá el precio mínimo:");
      if (precioIngresado !== null && precioIngresado.trim() !== "") {
        const precio = Number(precioIngresado);
        if (Number.isFinite(precio) && precio >= 0) {
          const filtrados = filtrarPorPrecio(precio);
          alert(`Se encontraron ${filtrados.length} videojuegos. Revisá la consola (F12).`);
        } else {
          alert("Ingresá un precio válido.");
        }
      }
    } else if (opcion === "4") {
      const categoria = prompt("Ingresá una categoría (Aventura, Deportes, Acción o Simulación):");
      if (categoria !== null && categoria.trim() !== "") {
        const hayCategoria = existeCategoria(categoria.trim());
        alert(hayCategoria ? `Sí, hay juegos de ${categoria}.` : `No hay juegos de ${categoria}.`);
      }
    } else {
      alert("Opción incorrecta. Elegí un número del 1 al 5.");
    }
  }
}

// 8) Búsqueda visual por nombre para usar directamente desde la página.
function mostrarCatalogo(lista) {
  const contenedor = document.querySelector("#lista-videojuegos");
  const contador = document.querySelector("#cantidad-juegos");
  const mensajeVacio = document.querySelector("#mensaje-vacio");

  contenedor.innerHTML = "";

  // forEach también se utiliza para generar las tarjetas del catálogo.
  lista.forEach((videojuego) => {
    const tarjeta = document.createElement("article");
    tarjeta.classList.add("tarjeta");

    const categoria = document.createElement("span");
    categoria.classList.add("categoria");
    categoria.textContent = videojuego.categoria;

    const nombre = document.createElement("h3");
    nombre.textContent = videojuego.nombre;

    const precio = document.createElement("p");
    precio.textContent = `Precio: $${videojuego.precio}`;

    const stock = document.createElement("p");
    stock.textContent = `Stock disponible: ${videojuego.stock}`;

    tarjeta.append(categoria, nombre, precio, stock);
    contenedor.appendChild(tarjeta);
  });

  contador.textContent = `${lista.length} ${lista.length === 1 ? "juego" : "juegos"}`;
  mensajeVacio.hidden = lista.length !== 0;
}

// Eventos de la página.
const buscador = document.querySelector("#buscador");
const botonLimpiar = document.querySelector("#limpiar-busqueda");
const botonMenu = document.querySelector("#abrir-menu");

buscador.addEventListener("input", () => {
  const texto = buscador.value.trim().toLowerCase();

  // filter() transforma el catálogo en una lista que coincide con la búsqueda.
  const resultados = catalogoVideojuegos.filter((videojuego) => {
    return videojuego.nombre.toLowerCase().includes(texto);
  });

  mostrarCatalogo(resultados);
});

botonLimpiar.addEventListener("click", () => {
  buscador.value = "";
  mostrarCatalogo(catalogoVideojuegos);
});

botonMenu.addEventListener("click", ejecutarMenu);

// Muestra el catálogo inicial cuando carga la página.
mostrarCatalogo(catalogoVideojuegos);

// Ejemplos automáticos en consola para verificar los métodos.
console.log("===== VERIFICACIÓN DE MÉTODOS =====");
listarVideojuegos();
buscarPorId(3);
filtrarPorPrecio(18000);
existeCategoria("Deportes");
